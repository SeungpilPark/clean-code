start();

function start() {
  console.log('start');
  next();
}

function next() {
  console.log('next');
  last();
}

function last() {
  console.log('last');
}
