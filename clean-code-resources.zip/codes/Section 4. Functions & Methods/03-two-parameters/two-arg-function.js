function login(email, password) {
  // Log a user in
  // ...
}

login('max@test.com', 'testpassword');



class Point {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }
}

const point = new Point(10, 13);



