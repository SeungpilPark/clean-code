function showErrorMessage(message, item = {}) {
  console.log(message);
  console.log(item);
}

exports.showErrorMessage = showErrorMessage;